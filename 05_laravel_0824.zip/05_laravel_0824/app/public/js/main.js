$.ajaxSetup({  /* ①-追加 */
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});
$.ajax({
  type:'POST',
  url: '/update',  /* ②-変更 */
  data: {
    id  :myNum,
    left:myLeft,
    top :myTop
  }
}).done(function(){