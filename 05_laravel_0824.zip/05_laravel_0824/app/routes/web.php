<?php


use App\Http\Controllers\SortableController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     /*return view('welcome');*/
//     return view('sortable');  /* welcomeとなっている部分をsortableに変更します */
// });←なんか前 の工程で追記したけど、「⑤ルーティングのweb.phpを修正する」で消すらしい。


// Route::get('/', [SortableController::class, 'index']);// ←「⑤ルーティングのweb.phpを修正する
#8 ↑Laravelアプリでデータを新規登録する方法」でコメント化した
// Route::get('/', 'SortableController@index');←Laravel 6のパスの指定の書き方



Route::get('/', [SortableController::class,'index']);
Route::post('/register', [SortableController::class,'register']);


#↓9 LaravelでAjaxのデータを登録する方法で④ルーティングファイルweb.phpを修正のためにLaravel9の書き方で追記した。
Route::post('/update', [SortableController::class,'update']);