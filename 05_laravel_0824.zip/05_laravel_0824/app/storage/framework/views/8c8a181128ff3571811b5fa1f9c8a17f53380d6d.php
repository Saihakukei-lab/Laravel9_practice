<?php $__currentLoopData = $sortables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sortable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="drag" data-num="<?php echo e($sortable->id); ?>" style="left:<?php echo e($sortable->left_x); ?>px; top:<?php echo e($sortable->top_y); ?>px;">
  <p><span class="name"><?php echo e($sortable->id); ?> <?php echo e($sortable->name); ?></span></p>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /var/www/app/resources/views/layouts/drags.blade.php ENDPATH**/ ?>