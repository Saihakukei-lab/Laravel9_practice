<!DOCTYPE html>
<html lang="ja">
<head>

<meta name="csrf-token" content="{{ csrf_token() }}">
<!-- ↑Ajaxのheadersに渡すためのCSRFトークンをHTMLに記述するらしいのでいれた -->

  <meta charset="UTF-8">
  <title>8001-cri-sortable</title>
  <link href="{{ asset('css/style.css')}}" rel="stylesheet">
</head>
<body>
<div id="wrapper">

<div id="input_form">
  @include('layouts.registrations')
  <!-- /* registrations.blade.phpを読み込む */ -->

</div>

<div id="drag-area">
  @include('layouts.drags')
</div>

</div>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js"></script>
  <script src="{{ asset('js/main.js')}}"></script>
</body>
</html>