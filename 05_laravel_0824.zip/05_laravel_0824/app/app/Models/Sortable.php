<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sortable extends Model
{
    // use HasFactory　←これはデフォルトで入ってたけどコメントアウトにしてみた　;
    public $timestamps = false;   /* ←なんか追加してみた*/
}
