# Laravel Database: Migrations

- <https://readouble.com/laravel/9.x/ja/migrations.html>
