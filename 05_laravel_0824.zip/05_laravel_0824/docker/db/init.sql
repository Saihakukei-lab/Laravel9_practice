-- DB生成「cbc_laravel」
CREATE DATABASE `cbc_laravel`;
