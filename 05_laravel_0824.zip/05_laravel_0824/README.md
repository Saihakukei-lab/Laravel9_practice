# バックエンド編課題

Laravelの環境を構築します。

## 環境構築

- [こちらを参照](https://github.com/epkotsoftware/training-docs/blob/main/training/05_laravel/README.md)
