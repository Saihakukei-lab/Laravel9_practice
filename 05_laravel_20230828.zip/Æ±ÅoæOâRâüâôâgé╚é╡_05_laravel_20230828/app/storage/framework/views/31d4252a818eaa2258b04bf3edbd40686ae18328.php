<!DOCTYPE html>
<html lang="ja">
<head>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


  <meta charset="UTF-8">
  <title>8001-cri-sortable</title>
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/reset.css')); ?>" rel="stylesheet">

</head>
<body>
<div id="wrapper">

<div id="input_form">
  <?php echo $__env->make('layouts.registrations', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</div>

<div id="drag-area">
  <?php echo $__env->make('layouts.drags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

</div>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js"></script>
  <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>
</html><?php /**PATH /var/www/app/resources/views/sortable.blade.php ENDPATH**/ ?>