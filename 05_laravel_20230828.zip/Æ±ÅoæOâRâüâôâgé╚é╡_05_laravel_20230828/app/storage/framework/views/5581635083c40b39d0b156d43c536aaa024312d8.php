<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li>
    <p><?php echo e($task->task); ?></p>
    <button class="delete_btn" data-id="<?php echo e($task->id); ?>">完了</button>
  </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /var/www/app/resources/views/layouts/myTasks.blade.php ENDPATH**/ ?>