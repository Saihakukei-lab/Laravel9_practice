<form action="<?php echo e(url( 'register' )); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

  <input type="text" name="inputName" placeholder="新メンバー名を入力">
  <input type="submit" value="登録">
</form><?php /**PATH /var/www/app/resources/views/layouts/registrations.blade.php ENDPATH**/ ?>