<form action="<?php echo e(url( 'task/register' )); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

  <input type="text" name="task" maxlength="30" placeholder="タスクを入力してください">
  <input type="submit" value="追加">
</form><?php /**PATH /var/www/app/resources/views/layouts/regists.blade.php ENDPATH**/ ?>