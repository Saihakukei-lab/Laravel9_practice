<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>MyTasks</title>
  <link href="<?php echo e(asset('css/reset.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/style2.css')); ?>" rel="stylesheet">
</head>
<body>
  <div id="wrap" class="wrap">

    <div class="task">

      <div class="task__new">
        <h2>新しいタスクを作成</h2>
        <?php echo $__env->make('layouts.regists', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>


      <div class="task__area">
        <h2>わたしのタスク一覧</h2>
        <ul class="task__area-list">
          <?php echo $__env->make('layouts.myTasks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
      </div>
    </div>

  </div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js"></script>
<script src="<?php echo e(asset('js/main2.js')); ?>"></script>
</body>
</html>

<?php /**PATH /var/www/app/resources/views/tasks.blade.php ENDPATH**/ ?>